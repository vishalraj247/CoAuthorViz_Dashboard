#! /usr/bin/bash
wget https://cs.stanford.edu/~minalee/zip/chi2022-coauthor-v1.0.zip
unzip -q chi2022-coauthor-v1.0.zip
rm chi2022-coauthor-v1.0.zip
